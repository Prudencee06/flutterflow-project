import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyD8CHM8fdiCvQmuAIXYK7B5UtJ42OubwIc",
            authDomain: "to-do-eb06c.firebaseapp.com",
            projectId: "to-do-eb06c",
            storageBucket: "to-do-eb06c.firebasestorage.app",
            messagingSenderId: "35119351975",
            appId: "1:35119351975:web:6ea92b1621072886037382"));
  } else {
    await Firebase.initializeApp();
  }
}
