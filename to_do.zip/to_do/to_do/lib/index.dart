// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/splash_screen/splash_screen_widget.dart' show SplashScreenWidget;
export '/tasks/tasks_widget.dart' show TasksWidget;
export '/pages/signup/signup_widget.dart' show SignupWidget;
export '/settings/settings_widget.dart' show SettingsWidget;
export '/pages/details_page/details_page_widget.dart' show DetailsPageWidget;
export '/completed/completed_widget.dart' show CompletedWidget;
